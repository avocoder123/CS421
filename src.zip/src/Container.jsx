import { useState, useCallback } from 'react';
import { Card } from './Card';
import update from 'immutability-helper';
const style = {
    width: 50
};
export const Container = () => {
        const [cards, setCards] = useState([
            {
                id: 1,
                image: '00.jpg',
            },
            {
                id: 2,
                image: '01.jpg',
            },
            {
                id: 3,
                image: '02.jpg',
            },
            {
                id: 4,
                image: '10.jpg',
            },
            {
                id: 5,
                image: '11.jpg',
            },
            {
                id: 6,
                image: '12.jpg',
            },
            {
                id: 7,
                image: '20.jpg',
            },
            {
                id: 8,
                image: '21.jpg',
            },
            {
                id: 9,
                image: '22.jpg',
            },
        ]);
        const moveCard = useCallback((dragIndex, hoverIndex) => {
            const dragCard = cards[dragIndex];
            setCards(update(cards, {
                $splice: [
                    [dragIndex, 1],
                    [hoverIndex, 0, dragCard],
                ],
            }));
        }, [cards]);
        const renderCard = (card, index) => {
            return (<Card key={card.id} index={index} id={card.id} image={card.image} moveCard={moveCard}/>);
        };
        return (<>
            <h1>Puzzle</h1>
				<div style= {{ display: "grid", gridTemplateColumns: "repeat(3, min-content)", gridTemplateRows: "repeat(3, min-content)" }}>{cards.map((card, i) => renderCard(card, i))}</div>
			</>);
    };
export { Container as default } from './Container'
