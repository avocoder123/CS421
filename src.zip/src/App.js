import React, { Component } from 'react';
import './App.css';
import {BrowserRouter, Route} from "react-router-dom";
import { render } from 'react-dom'

import { DndProvider } from 'react-dnd'
import { HTML5Backend } from 'react-dnd-html5-backend'
import Navigation from "./Navigation";
import TOH from "./TOH";

import './App.css';
import Home from "./Home";
import Sources from "./Sources";
import Container from "./Container";

class App extends Component {
    render() {
        return (
            <div className="App">
                <BrowserRouter>
                    <div className="App">
                       <Navigation/>
                        <Route exact path='/'> <Home/></Route>
                        <DndProvider backend={HTML5Backend}>
                            <Route exact path='/Puzzle'>
                                <Container />
                            </Route>
                        </DndProvider>
                        <Route exact path='/TOH' component={TOH}/>
                        <Route exact path='/Sources'> <Sources/></Route>
                    </div>
                </BrowserRouter>
            </div>
        );
    }
}

export default App;



