import React, { Component } from 'react'
import { DragSource } from "react-dnd";

const itemSource = {
    beginDrag(props) {
        return props.item;
    }
}
function collect(connect, monitor) {
    return {
        connectDragSource: connect.dragSource(),
        connectDragPreview: connect.dragPreview(),
        isDragging: monitor.isDragging()
    }
}
class Tower extends Component {
        render() {
        const {connectDragSource, item } = this.props;
        let ring1style = 'ring ring' + item.item.rings[0];
        let ring2style = 'ring ring' + item.item.rings[1];
        let ring3style = 'ring ring' + item.item.rings[2];

        return connectDragSource(
            <div>
                <div className="tower" >
                    <div className={ring1style}/>
                    <div className={ring2style}/>
                    <div className={ring3style}/>
                </div>
            </div>
        )
    }
}


export default DragSource('item', itemSource, collect)(Tower)
