import React, {Component} from 'react'
import Tower from './Tower'
import Target from "./Target"
import { DndProvider } from 'react-dnd'
import { HTML5Backend } from 'react-dnd-html5-backend'
import './TOH.css'

export default class TOH extends Component {
    state = {
        towers: [
            {id: 0, name: 'Tower 0', rings: [1,2,3]},
            {id: 1, name: 'Tower 1', rings: [null,null,null],[null]: [null]},
            {id: 2, name: 'Tower 2', rings: [null,null,null],[null]: [null]}
        ],
        winState: [1,2,3]
    }



    move = (fromTower, toTower) => {
            if (this.Ring(fromTower).value !== null) {
                if (this.Ring(toTower).value == null) {
                    this.state.towers[fromTower].rings[this.Ring(fromTower).height] = null;
                    this.state.towers[toTower].rings[this.Ring(toTower).height] = this.Ring(fromTower).value;
                } else {
                    if (this.Ring(fromTower).value < this.Ring(toTower).value) {
                        if (this.Ring(toTower).height-1 !== -1 && this.state.towers[toTower].rings[this.Ring(toTower).height-1] == null) {
                            this.state.towers[fromTower].rings[this.Ring(fromTower).height] = null;
                            this.state.towers[toTower].rings[this.Ring(toTower).height-1] = this.Ring(fromTower).value;
                        }
                    }
                }
                this.setState({
                    towers: this.state.towers
                });
            }
    };
    Ring = (tower) => {
        for (let i = 0; i < this.state.towers[tower].rings.length; i++) {
            if (this.state.towers[tower].rings[i] != null) {
                return {
                    height: i,
                    value: this.state.towers[tower].rings[i]
                }
            }
        }
        return {
            height: 2,
        };
    };
    render() {
        return (
            <DndProvider backend={HTML5Backend}>
            <div>
                <div className="container">
                    <h1>Towers of Hanoi</h1>
                    <div className="row"  >
                        <div className="col s12" >
                            <div className="card teal darken-5">
                                <div className="card-content white-text">
                                    <div className="game-container">
                                        {this.state.towers.map((item, index) => (
                                            <Target key={index} handleDrop={(from, to) => {
                                                this.move(from, to);
                                            }}>
                                                <Tower key={item.id} item={{item}}/>
                                            </Target>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </DndProvider>
        )
    }
}
