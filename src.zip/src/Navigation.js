import React, { Component } from 'react';
import "./materialize.css"
import './App.css';
import {BrowserRouter, Link, NavLink, Route} from "react-router-dom";
import {DndProvider} from "react-dnd";
import {HTML5Backend} from "react-dnd-html5-backend";




class Navigation extends Component {
    render() {
        return (
            <div>

                {/*<nav>*/}
                {/*    <div className="nav-wrapper">*/}
                {/*        <a href="#" className="brand-logo">Logo</a>*/}
                {/*        <ul id="nav-mobile" className="right hide-on-med-and-down">*/}
                {/*            <li><a href="sass.html">Sass</a></li>*/}
                {/*            <li><a href="badges.html">Components</a></li>*/}
                {/*            <li><a href="collapsible.html">JavaScript</a></li>*/}
                {/*        </ul>*/}
                {/*    </div>*/}
                {/*</nav>*/}

                <nav className="nav-wrapper teal darken-2">
                   <div>
                      <h1> <Link to="/" className="brand-logo center hide-on-med-and-down ">CMPSC 421</Link> </h1>
                       <ul className="right">
                           <li><NavLink to="/">HOME</NavLink></li>
                           <li><NavLink to="/TOH">TOWERS OF HANOI</NavLink></li>
                           <DndProvider backend={HTML5Backend}>
                               <li><NavLink to="/Puzzle"> PUZZLE</NavLink></li> </DndProvider>
                           <li> <NavLink to="/Sources">SOURCES </NavLink> </li>
                       </ul>
                   </div>

                </nav>

            </div>
        );
    }
}

export default Navigation
