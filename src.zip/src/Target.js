import React, { Component } from 'react'
import { DropTarget } from "react-dnd";

const moves = {
    drop(props, monitor) {
        if (monitor.didDrop()) {
            return
        }
        const item = monitor.getItem();
        return props.handleDrop(item.item.id, parseInt(props.children.key))
    }
}
function collect(connect, monitor) {
    return {
        connectDropTarget: connect.dropTarget(),
        hovered: monitor.isOver(),
        item: monitor.getItem()
    }
}
class Target extends Component {
    render(props) {
        const { connectDropTarget} = this.props;
        return connectDropTarget(
            <div className="target" style={{background: 'white'}}>
                {this.props.children}
            </div>
        )
    }
}
export default DropTarget('item', moves, collect)(Target)
