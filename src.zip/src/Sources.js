import React, {Component} from 'react'
import "./materialize.css"

class Sources extends Component {
    render() {
        return (
            <div>
                <div className="container">

                    <ul className="container-item">
                        <li>
                            <div className="col s12 m7">
                                <h2 className="header">References</h2>
                                <div className="card horizontal">
                                    <div className="card-stacked">
                                        <div className="card-content">
                                            <ul>
                                               <li><a href="url">https://materializecss.com/</a> </li>
                                                <li> <a href="url">https://www.w3schools.com/html/html_links.asp</a> </li>
                                                <li> <a href="url">https://en.wikipedia.org/wiki/Sliding_puzzle</a> </li>
                                                <li><a href="url">https://www.w3.org/Style/Examples/007/center.en.tmpl</a> </li>
                                                <li> <a href="url">https://github.com/imh0wie/Hanoi-Tower</a></li>
                                                <li>  <a href="url">https://medium.com/elm-shorts/elm-drag-and-drop-game-630205556d2</a></li>
                                                <li>  <a href="url">https://reactresources.com/topics/game-development</a></li>
                                                <li>  <a href="url">https://codesandbox.io/s/github/react-dnd/react-dnd/tree/gh-pages/examples_hooks_js/04-sortable/simple?file=/src/Container.jsx</a></li>
                                                <li> <a href="url">https://en.wikipedia.org/wiki/Tower_of_Hanoi</a></li>
                                                <li> <a href="url">https://github.com/diogosouza/logrocket-hanoi-tower</a></li>
                                                <li> <a href="url">https://blog.logrocket.com/using-react-dnd-to-create-a-tower-of-hanoi-game/</a></li>
                                                <li> <a href="url"> https://react-dnd.github.io/react-dnd/about</a></li>
                                                <li> <a href="url">https://www.npmjs.com/package/react-beautiful-dnd</a></li>
                                                <li> <a href="url">https://stackoverflow.com/questions/48811165/how-does-react-dnds-connectdragpreview-work</a></li>
                                                <li> <a href="url">https://stackoverflow.com/questions/41947474/dynamically-loading-local-images-with-reactjs</a></li>
    </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        )
    }
}

export default Sources;
