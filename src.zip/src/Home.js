import React, {Component} from 'react'
import {Link} from "react-router-dom";
import "./materialize.css"

class Home extends Component {
    render() {
        return (
            <div>
                <h1>Game Arcade </h1>
                <div className="container">
                    <p> You have two options for navigation. You can click the buttons or you can click on the navigation tabs above to re-navigate. </p>
                    <ul className="container-item">
                        <li>
                            <div className="col s12 m7">
                                <h2 className="header">Towers Of Hanoi</h2>
                                <div className="card horizontal">
                                    <div className="card-stacked">
                                        <div className="card-content">
                                            <p>The Tower of Hanoi (also called the Tower of Brahma or Lucas' Tower and sometimes pluralized as Towers, or simply pyramid puzzle) is a mathematical game or puzzle. It consists of three rods and a number of disks of different diameters, which can slide onto any rod.</p>
                                        </div>
                                        <div className="card-action">
                                            <a className="waves-effect waves-light btn-large  teal lighten-5" ><Link to="/TOH" style={{color: "black"}}>Towers of Hanoi</Link></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li>
                            <div className="col s12 m7">
                                <h2 className="header">Sliding Puzzle </h2>
                                <div className="card horizontal">
                                    <div className="card-stacked">
                                        <div className="card-content">
                                            <p>A sliding puzzle, sliding block puzzle, or sliding tile puzzle is a combination puzzle that challenges a player to slide (frequently flat) pieces along certain routes (usually on a board) to establish a certain end-configuration. The pieces to be moved may consist of simple shapes, or they may be imprinted with colours, patterns, sections of a larger picture (like a jigsaw puzzle), numbers, or letters.</p>
                                        </div>
                                        <div className="card-action">
                                            <a className="waves-effect waves-light btn-large teal lighten-5" ><Link to="/Puzzle" style={{color: "Black"}}>Puzzle</Link></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div className="col s12 m7">
                                <h2 className="header">Sources </h2>
                                <div className="card horizontal">
                                    <div className="card-stacked">
                                        <div className="card-content">
                                            <p>I got help from Z with towers of hanoi backend part but it does not work as anticipated. For the puzzle, I used the sandbox code which is linked.</p>
                                        </div>
                                        <div className="card-action">
                                            <a className="waves-effect waves-light btn-large teal lighten-5" ><Link to="/Sources" style={{color: "Black"}}>SOURCES</Link></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        )
    }
}

export default Home;
